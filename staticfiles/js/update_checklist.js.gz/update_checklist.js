// FUNCIONES PARA FORMULARIOS MULTIPLES DE CHECKLIST

btnChecklist = document.getElementById("btn_update_checklist");

btnChecklist.addEventListener('click', function(){
    // Obtenenemos los 3 formularios
    let = form = document.getElementById("form_update_checklist");

    // Enviar y guardar
    form.submit();
})